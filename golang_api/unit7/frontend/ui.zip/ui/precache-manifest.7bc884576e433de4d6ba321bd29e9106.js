self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "46aee028ef6c73903edea7200e8eb5bd",
    "url": "/index.html"
  },
  {
    "revision": "acaf6593f9bda88c393d",
    "url": "/static/css/2.ad76a385.chunk.css"
  },
  {
    "revision": "acaf6593f9bda88c393d",
    "url": "/static/js/2.de368096.chunk.js"
  },
  {
    "revision": "51226e8a0756b014f698d6db650df37c",
    "url": "/static/js/2.de368096.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e18fb110454604a48947",
    "url": "/static/js/main.affc0478.chunk.js"
  },
  {
    "revision": "717be7891cc3d466bc4e",
    "url": "/static/js/runtime-main.b43b082e.js"
  },
  {
    "revision": "73636e8103c161ac970089bd4797f550",
    "url": "/static/media/sathit.73636e81.png"
  },
  {
    "revision": "8f784fcfd2d16d2d24035e49cfcce50b",
    "url": "/static/media/sombut.8f784fcf.png"
  },
  {
    "revision": "b68b4d9bb06a456f8cff82a1d7098127",
    "url": "/static/media/somchai.b68b4d9b.png"
  },
  {
    "revision": "f65b03eefefee84b602ae5c95ef288ff",
    "url": "/static/media/somprasong.f65b03ee.png"
  },
  {
    "revision": "292cd7973f7df3c1d41883e676b260e3",
    "url": "/static/media/sornthep.292cd797.png"
  }
]);